// application-page/App.tsx
import React, { useState, useCallback } from "react";
import { supabase } from "./lib/supabaseClient";
import RegistrationForm from "./components/RegistrationForm";
import ConfirmationMessage from "./components/ConfirmationMessage";
import type { FormData as RegistrationFormData } from "./types";

const initialFormData: RegistrationFormData = {
  businessName: "",
  firstName: "",
  lastName: "",
  email: "",
  password: "",
  confirmPassword: "",
  socialMedia: "",
  businessNiche: "",
  logo: null,
};

type FormErrors = Partial<Record<keyof RegistrationFormData, string>> & { submit?: string };

const App: React.FC = () => {
  const [formData, setFormData] = useState<RegistrationFormData>(initialFormData);
  const [errors, setErrors] = useState<FormErrors>({});
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  // ✅ new: keep what to show on the success screen
  const [confirmation, setConfirmation] = useState<{ email: string; logoUrl?: string | null } | null>(null);

  const handleInputChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
      const { name, value } = e.target;
      setFormData((prev) => ({ ...prev, [name]: value }));
      if (errors[name as keyof FormErrors]) {
        setErrors((prev) => {
          const copy = { ...prev };
          delete copy[name as keyof FormErrors];
          return copy;
        });
      }
    },
    [errors]
  );

  const handleFileChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files ? e.target.files[0] : null;
    setFormData((prev) => ({ ...prev, logo: file }));
    if (errors.logo) {
      setErrors((prev) => {
        const copy = { ...prev };
        delete copy.logo;
        return copy;
      });
    }
  }, [errors]);

  const handleSubmit = async (payload: RegistrationFormData) => {
    setSubmitting(true);
    setErrors({});

    try {
      // 1) optional upload
      let logoPath: string | null = null;
      if (payload.logo) {
        const ext = payload.logo.name.split(".").pop() || "bin";
        const fileName = `registrations/${crypto.randomUUID()}.${ext}`;
        const { data: up, error: upErr } = await supabase
          .storage
          .from("logos")
          .upload(fileName, payload.logo, { contentType: payload.logo.type });
        if (upErr) throw upErr;
        logoPath = up.path; // e.g. "registrations/uuid.png"
      }

      // 2) insert row
      const { error: dbErr } = await supabase.from("registrations").insert({
        business_name: payload.businessName,
        first_name: payload.firstName || "",
        last_name: payload.lastName || "",
        email: payload.email,
        social_media: payload.socialMedia || null,
        business_niche: payload.businessNiche,
        logo_filename: logoPath,
      });
      if (dbErr) {
        if (/duplicate key value|unique/i.test(dbErr.message)) {
          throw new Error("This email is already registered.");
        }
        throw dbErr;
      }

      // ✅ 3) compute public URL for the logo (only if the bucket is PUBLIC)
      let publicLogoUrl: string | null = null;
      if (logoPath) {
        const { data } = supabase.storage.from("logos").getPublicUrl(logoPath);
        publicLogoUrl = data.publicUrl;
      }

      setConfirmation({ email: payload.email, logoUrl: publicLogoUrl });
      setIsSubmitted(true);
    } catch (err: any) {
      console.error("Registration failed:", err);
      setErrors((prev) => ({ ...prev, submit: err.message || "Unexpected error. Try again." }));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-secondary flex items-center justify-center p-4 sm:p-6 lg:p-8">
      <main className="w-full max-w-2xl mx-auto">
        <div className="bg-white rounded-xl shadow-lg p-8 md:p-12 transition-all duration-500">
          {isSubmitted ? (
            // ✅ pass confirmation props
            <ConfirmationMessage email={confirmation?.email ?? ""} logoUrl={confirmation?.logoUrl ?? undefined} />
          ) : (
            <RegistrationForm
              formData={formData}
              errors={errors}
              onInputChange={handleInputChange}
              onFileChange={handleFileChange}
              onSubmit={handleSubmit}
            />
          )}
          {!isSubmitted && errors.submit && (
            <p className="mt-4 text-sm text-red-600">{errors.submit}</p>
          )}
          {!isSubmitted && submitting && (
            <p className="mt-4 text-sm text-zinc-500">Submitting...</p>
          )}
        </div>
      </main>
    </div>
  );
};

export default App;
