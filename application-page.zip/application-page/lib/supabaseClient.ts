// application-page/lib/supabaseClient.ts
import { createClient } from '@supabase/supabase-js';

export const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL!,
  import.meta.env.VITE_SUPABASE_ANON_KEY!
);

// (optional) quick sanity log — remove later
console.log(
  '[supabase env]',
  (import.meta.env.VITE_SUPABASE_URL || '').replace(/(https:\/\/)(.*?)(\.supabase\.co)/, '$1***$3'),
  (import.meta.env.VITE_SUPABASE_ANON_KEY || '').slice(0, 8) + '…'
);
